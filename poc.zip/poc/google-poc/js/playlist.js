var data = {
  "songs": [
    {
      "fileName": "https://www.ruse-problem.org/songs/RunningWaters.mp3",
      "singer": "Jason Shaw",
      "songName": "Running Waters"
    },
    {
      "fileName": "https://www.ruse-problem.org/songs/Enthusiast.mp3",
      "singer": "Tours",
      "songName": "Enthusiast"
    },
    {
      "fileName": "https://www.ruse-problem.org/songs/SkyRide.mp3",
      "singer": "Itasca",
      "songName": "Sky Ride"
    },
    {
      "fileName": "https://www.ruse-problem.org/songs/Starling.mp3",
      "singer": "Podington Bear",
      "songName": "Starling"
    },
    {
      "fileName": "https://www.ruse-problem.org/songs/HachikoTheFaithtfulDog.mp3",
      "singer": "The Kyoto Connection",
      "songName": "Hachiko The Faithful Dog"
    },
    {
      "fileName": "https://www.ruse-problem.org/songs/FaterLee.mp3",
      "singer": "Black Ant",
      "songName": "Father Lee"
    },
    {
      "fileName": "https://www.ruse-problem.org/songs/EpicSong.mp3",
      "singer": "BoxCat Games",
      "songName": "Epic Song"
    }
  ]
};
